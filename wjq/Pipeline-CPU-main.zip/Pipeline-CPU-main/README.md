use TOP.v to generate bitstream file,then run it on FPGA!

you can also use provided file!
